import React, { useEffect, useState } from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import HomeScreen, { Mode } from './src/screens/HomeScreen';
import HostScreen from './src/screens/HostScreen';
import GuestScreen from './src/screens/GuestScreen';
import { DEFAULT_RELAY_URL, RELAY_STORAGE_KEY } from './src/utils/config';
import { C } from './src/theme';

type Screen = { name: 'home' } | { name: 'host'; mode: Mode } | { name: 'guest'; mode: Mode };

export default function App() {
  const [screen, setScreen] = useState<Screen>({ name: 'home' });
  const [relayUrl, setRelayUrlState] = useState(DEFAULT_RELAY_URL);

  useEffect(() => {
    AsyncStorage.getItem(RELAY_STORAGE_KEY)
      .then((v) => {
        if (v) setRelayUrlState(v);
      })
      .catch(() => {});
  }, []);

  const setRelayUrl = (u: string) => {
    setRelayUrlState(u);
    AsyncStorage.setItem(RELAY_STORAGE_KEY, u).catch(() => {});
  };

  const home = () => setScreen({ name: 'home' });

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar style="light" />
      {screen.name === 'home' && (
        <HomeScreen
          relayUrl={relayUrl}
          setRelayUrl={setRelayUrl}
          onHost={(mode) => setScreen({ name: 'host', mode })}
          onGuest={(mode) => setScreen({ name: 'guest', mode })}
        />
      )}
      {screen.name === 'host' && <HostScreen key={'h' + screen.mode} mode={screen.mode} relayUrl={relayUrl} onLeave={home} />}
      {screen.name === 'guest' && <GuestScreen key={'g' + screen.mode} mode={screen.mode} relayUrl={relayUrl} onLeave={home} />}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
});
