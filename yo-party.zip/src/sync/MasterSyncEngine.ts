import { AudioPlayer } from '../audio/AudioPlayer';
import { HostTransport } from '../transport/types';
import { nowMs } from '../utils/time';
import { SyncEvent, SyncPayload } from './protocol';

/**
 * MODULE 1 - HOST SIDE. Identical for offline (TCP hotspot) and online (relay) transports.
 *
 * Every playback event: the host starts/changes audio, captures its own clock IMMEDIATELY after the
 * native player confirms, and broadcasts {event, host_start_timestamp, position_ms, track_uri}.
 * Guests derive the live position from that anchor - the host never polls/re-broadcasts state.
 */
export class MasterSyncEngine {
  private snapshot: SyncPayload | null = null;
  private guestIds = new Set<string>();
  private queue: Promise<void> = Promise.resolve();

  onGuestsChanged?: (ids: string[]) => void;
  onStateChanged?: (s: SyncPayload | null) => void;
  onError?: (msg: string) => void;

  constructor(private transport: HostTransport, private player: AudioPlayer) {
    transport.onGuestJoin((id) => {
      this.guestIds.add(id);
      this.onGuestsChanged?.([...this.guestIds]);
      // Late joiner gets the current anchor at once, so it syncs to the right spot immediately.
      if (this.snapshot) {
        transport.send(id, { type: 'LOAD', track_uri: this.snapshot.track_uri });
        transport.send(id, this.snapshot);
      }
    });
    transport.onGuestLeave((id) => {
      this.guestIds.delete(id);
      this.onGuestsChanged?.([...this.guestIds]);
    });
    transport.onMessage((id, msg) => {
      if (msg && msg.type === 'PING') {
        const t1 = nowMs(); // capture first
        transport.send(id, { type: 'PONG', id: msg.id, t0: msg.t0, t1, t2: nowMs() });
      }
    });
    player.onFinish = () => this.enqueue(async () => this.handleFinish());
  }

  getSnapshot() {
    return this.snapshot;
  }

  private enqueue(fn: () => Promise<void>): Promise<void> {
    this.queue = this.queue.then(fn).catch((e) => this.onError?.(String((e && e.message) || e)));
    return this.queue;
  }

  private publish(event: SyncEvent, ts: number, positionMs: number, uri: string, playing: boolean) {
    const payload: SyncPayload = {
      type: 'SYNC',
      event,
      host_start_timestamp: ts,
      position_ms: positionMs,
      track_uri: uri,
      playing,
    };
    this.snapshot = payload;
    this.transport.broadcast(payload);
    this.onStateChanged?.(payload);
  }

  /** New track: guests are told to preload, host loads, then PLAY from 0. */
  playTrack(uri: string) {
    return this.enqueue(async () => {
      this.transport.broadcast({ type: 'LOAD', track_uri: uri });
      await this.player.load(uri);
      const st = await this.player.playAt(0);
      const ts = nowMs(); // host clock at the moment playback is confirmed
      this.publish('PLAY', ts, st?.positionMillis ?? 0, uri, true);
    });
  }

  resume() {
    return this.enqueue(async () => {
      const s = this.snapshot;
      if (!s || s.playing) return;
      const st = await this.player.playAt(s.position_ms);
      this.publish('PLAY', nowMs(), st?.positionMillis ?? s.position_ms, s.track_uri, true);
    });
  }

  pause() {
    return this.enqueue(async () => {
      const s = this.snapshot;
      if (!s || !s.playing) return;
      const st = await this.player.pauseAt();
      this.publish('PAUSE', nowMs(), st?.positionMillis ?? 0, s.track_uri, false);
    });
  }

  seekTo(ms: number) {
    return this.enqueue(async () => {
      const s = this.snapshot;
      if (!s) return;
      const dur = this.player.durationMs;
      const target = Math.max(0, dur > 0 ? Math.min(ms, dur - 100) : ms);
      if (s.playing) {
        const st = await this.player.playAt(target);
        this.publish('SEEK', nowMs(), st?.positionMillis ?? target, s.track_uri, true);
      } else {
        const st = await this.player.pauseAt(target);
        this.publish('SEEK', nowMs(), st?.positionMillis ?? target, s.track_uri, false);
      }
    });
  }

  seekBy(deltaMs: number) {
    return this.enqueue(async () => {
      const st = await this.player.getStatus();
      if (!st || !st.isLoaded) return;
      const s = this.snapshot;
      if (!s) return;
      const dur = this.player.durationMs;
      const target = Math.max(0, dur > 0 ? Math.min(st.positionMillis + deltaMs, dur - 100) : st.positionMillis + deltaMs);
      const res = s.playing ? await this.player.playAt(target) : await this.player.pauseAt(target);
      this.publish('SEEK', nowMs(), res?.positionMillis ?? target, s.track_uri, s.playing);
    });
  }

  private async handleFinish() {
    const s = this.snapshot;
    if (!s || !s.playing) return;
    this.publish('PAUSE', nowMs(), this.player.durationMs, s.track_uri, false);
  }

  dispose() {
    this.player.onFinish = undefined;
  }
}
