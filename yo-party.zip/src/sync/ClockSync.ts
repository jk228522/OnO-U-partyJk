import { nowMs } from '../utils/time';
import { PingMessage, PongMessage, SYNC_CONFIG } from './protocol';

/**
 * NTP-style clock offset estimation between Guest and Host over the SAME channel that carries
 * audio events (TCP hotspot or online relay) - no external time server.
 *
 * Guest sends PING{t0}. Host answers PONG{t0,t1,t2} (t1 = host receive time, t2 = host send time).
 * Guest receives at t3.
 *   rtt    = (t3 - t0) - (t2 - t1)
 *   offset = ((t1 - t0) + (t2 - t3)) / 2      // offset = hostClock - guestClock
 * The sample with the smallest RTT in a sliding window is the most trustworthy.
 */
export class ClockSync {
  offsetMs = 0;
  rttMs = 0;
  sampleCount = 0;
  private samples: { rtt: number; offset: number }[] = [];
  private nextId = 1;
  private timers: any[] = [];
  private readyWaiters: (() => void)[] = [];

  constructor(private sendPing: (m: PingMessage) => void) {}

  start() {
    for (let i = 0; i < SYNC_CONFIG.CLOCK_BURST_COUNT; i++) {
      this.timers.push(setTimeout(() => this.ping(), i * SYNC_CONFIG.CLOCK_BURST_GAP_MS));
    }
    this.timers.push(setInterval(() => this.ping(), SYNC_CONFIG.CLOCK_PING_INTERVAL_MS));
  }

  stop() {
    this.timers.forEach((t) => {
      clearTimeout(t);
      clearInterval(t);
    });
    this.timers = [];
    this.readyWaiters.forEach((w) => w());
    this.readyWaiters = [];
  }

  private ping() {
    try {
      this.sendPing({ type: 'PING', id: this.nextId++, t0: nowMs() });
    } catch {
      /* connection may be closing */
    }
  }

  handlePong(m: PongMessage) {
    const t3 = nowMs(); // capture FIRST
    const rtt = Math.max(0, t3 - m.t0 - (m.t2 - m.t1));
    const offset = (m.t1 - m.t0 + (m.t2 - t3)) / 2;
    this.samples.push({ rtt, offset });
    if (this.samples.length > SYNC_CONFIG.CLOCK_SAMPLE_WINDOW) this.samples.shift();
    let best = this.samples[0];
    for (const s of this.samples) if (s.rtt < best.rtt) best = s;
    this.offsetMs = best.offset;
    this.rttMs = best.rtt;
    this.sampleCount++;
    if (this.sampleCount >= 3) {
      this.readyWaiters.forEach((w) => w());
      this.readyWaiters = [];
    }
  }

  /** Current time expressed in the HOST's clock domain. */
  hostNow(): number {
    return nowMs() + this.offsetMs;
  }

  waitReady(timeoutMs = 2500): Promise<void> {
    if (this.sampleCount >= 3) return Promise.resolve();
    return new Promise((resolve) => {
      const t = setTimeout(resolve, timeoutMs);
      this.readyWaiters.push(() => {
        clearTimeout(t);
        resolve();
      });
    });
  }
}
