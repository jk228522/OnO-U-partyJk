export type SyncEvent = 'PLAY' | 'SEEK' | 'PAUSE';

/** Main broadcast payload. Field names follow the spec; position_ms/playing are extras
 *  that make RESUME / SEEK / late-join work with the same handler. */
export interface SyncPayload {
  type: 'SYNC';
  event: SyncEvent;
  /** Host clock (ms) at the instant the host was at `position_ms`. */
  host_start_timestamp: number;
  /** Track position (ms) at host_start_timestamp. 0 for a fresh PLAY. */
  position_ms: number;
  track_uri: string;
  playing: boolean;
}
export interface LoadMessage { type: 'LOAD'; track_uri: string }
export interface PingMessage { type: 'PING'; id: number; t0: number }
export interface PongMessage { type: 'PONG'; id: number; t0: number; t1: number; t2: number }

export const SYNC_CONFIG = {
  DRIFT_THRESHOLD_MS: 15,      // start correcting above this
  DRIFT_RELEASE_MS: 5,         // stop rate-correction below this (hysteresis)
  HARD_SEEK_MS: 250,           // above this: micro-seek instead of rate change
  DRIFT_INTERVAL_MS: 500,
  MAX_RATE_DELTA: 0.05,        // playback rate clamp 0.95 .. 1.05
  CLOCK_PING_INTERVAL_MS: 5000,
  CLOCK_BURST_COUNT: 8,
  CLOCK_BURST_GAP_MS: 80,
  CLOCK_SAMPLE_WINDOW: 8,
  TCP_PORT: 8765,
};
