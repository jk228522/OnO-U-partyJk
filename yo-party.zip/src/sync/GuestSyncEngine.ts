import { AudioPlayer } from '../audio/AudioPlayer';
import { GuestTransport } from '../transport/types';
import { nowMs } from '../utils/time';
import { ClockSync } from './ClockSync';
import { SYNC_CONFIG, SyncPayload } from './protocol';

export interface GuestStats {
  offsetMs: number;
  rttMs: number;
  driftMs: number;
  rate: number;
  playing: boolean;
  uri: string | null;
  clockSamples: number;
}

/**
 * MODULE 1 - GUEST SIDE. Identical for offline (TCP hotspot) and online (relay) transports.
 *
 *   dt        = guest_received_time(in HOST clock) - host_start_timestamp        (> 0 normally)
 *   position  = position_ms + dt
 * The guest loads the track, then computes dt AT THE MOMENT it starts (not when the message
 * arrived), so load time is compensated too, and starts playback directly at `position`.
 * Afterwards a drift loop keeps it within DRIFT_THRESHOLD_MS of the host.
 */
export class GuestSyncEngine {
  private clock: ClockSync;
  private anchor: SyncPayload | null = null;
  private loadedUri: string | null = null;
  private loading: { uri: string; promise: Promise<void> } | null = null;
  private queue: Promise<void> = Promise.resolve();
  private driftTimer: any = null;
  private driftBusy = false;
  private busy = 0;
  private rate = 1;
  private lastDrift = 0;
  private seekCostMs = 30;

  onError?: (msg: string) => void;

  constructor(transport: GuestTransport, private player: AudioPlayer) {
    this.clock = new ClockSync((m) => transport.send(m));
    transport.onMessage((msg) => this.onMessage(msg));
  }

  start() {
    this.clock.start();
  }

  private onMessage(msg: any) {
    switch (msg && msg.type) {
      case 'PONG':
        this.clock.handlePong(msg); // synchronous: t3 must be captured immediately
        break;
      case 'LOAD':
        this.enqueue(() => this.ensureLoaded(msg.track_uri));
        break;
      case 'SYNC':
        this.anchor = msg as SyncPayload; // latest anchor always wins
        this.enqueue(() => this.apply());
        break;
    }
  }

  private enqueue(fn: () => Promise<void>) {
    this.queue = this.queue.then(fn).catch((e) => this.onError?.(String((e && e.message) || e)));
  }

  private async ensureLoaded(uri: string) {
    if (this.loadedUri === uri) return;
    if (this.loading && this.loading.uri === uri) return this.loading.promise;
    const p = (async () => {
      this.loadedUri = null;
      await this.player.load(uri);
      this.loadedUri = uri;
    })();
    this.loading = { uri, promise: p };
    try {
      await p;
    } finally {
      if (this.loading && this.loading.promise === p) this.loading = null;
    }
  }

  /** Live host position for anchor `a`, evaluated at local time `atLocal`. */
  private expectedPositionMs(a: SyncPayload, atLocal: number = nowMs()): number {
    if (!a.playing) return a.position_ms;
    const dt = Math.max(0, atLocal + this.clock.offsetMs - a.host_start_timestamp);
    let p = a.position_ms + dt;
    const dur = this.player.durationMs;
    if (dur > 0) p = Math.min(p, dur);
    return p;
  }

  private async apply() {
    this.busy++;
    try {
      const first = this.anchor;
      if (!first) return;
      await this.clock.waitReady();
      await this.ensureLoaded(first.track_uri);
      const cur = this.anchor!;
      if (cur.track_uri !== this.loadedUri) return; // a newer track is queued; its apply() handles it
      if (cur.playing) {
        const t0 = nowMs();
        const target = this.expectedPositionMs(cur) + this.seekCostMs / 2;
        const dur = this.player.durationMs;
        if (dur > 0 && target >= dur - 30) {
          this.stopDrift();
          await this.player.pauseAt(dur);
          return;
        }
        await this.player.playAt(target, 1);
        this.rate = 1;
        this.seekCostMs = Math.min(300, 0.7 * this.seekCostMs + 0.3 * (nowMs() - t0));
        this.startDrift();
      } else {
        this.stopDrift();
        await this.player.pauseAt(cur.position_ms);
        this.rate = 1;
      }
    } finally {
      this.busy--;
    }
  }

  private startDrift() {
    if (this.driftTimer) return;
    this.driftTimer = setInterval(() => this.driftTick(), SYNC_CONFIG.DRIFT_INTERVAL_MS);
  }

  private stopDrift() {
    if (this.driftTimer) clearInterval(this.driftTimer);
    this.driftTimer = null;
  }

  private async driftTick() {
    if (this.busy > 0 || this.driftBusy) return;
    const a = this.anchor;
    if (!a || !a.playing) return;
    this.driftBusy = true;
    try {
      const ta = nowMs();
      const st = await this.player.getStatus();
      const tb = nowMs();
      if (!st || !st.isLoaded || !st.isPlaying) return; // buffering / stopped: nothing to correct
      // The native position was sampled somewhere between ta and tb - compare at the midpoint.
      const expected = this.expectedPositionMs(a, (ta + tb) / 2);
      const drift = st.positionMillis - expected; // > 0 : guest is AHEAD of host
      this.lastDrift = drift;
      const abs = Math.abs(drift);
      if (abs > SYNC_CONFIG.HARD_SEEK_MS) {
        const t0 = nowMs();
        await this.player.setPosition(this.expectedPositionMs(a) + this.seekCostMs / 2);
        this.seekCostMs = Math.min(300, 0.7 * this.seekCostMs + 0.3 * (nowMs() - t0));
        if (this.rate !== 1) {
          await this.player.setRate(1);
          this.rate = 1;
        }
      } else if (abs > SYNC_CONFIG.DRIFT_THRESHOLD_MS) {
        const d = SYNC_CONFIG.MAX_RATE_DELTA;
        const r = Math.max(1 - d, Math.min(1 + d, 1 - drift / 1000)); // ahead -> slow down
        if (Math.abs(r - this.rate) > 0.002) {
          await this.player.setRate(r);
          this.rate = r;
        }
      } else if (abs <= SYNC_CONFIG.DRIFT_RELEASE_MS && this.rate !== 1) {
        await this.player.setRate(1);
        this.rate = 1;
      }
    } catch (e: any) {
      this.onError?.(String((e && e.message) || e));
    } finally {
      this.driftBusy = false;
    }
  }

  getStats(): GuestStats {
    return {
      offsetMs: this.clock.offsetMs,
      rttMs: this.clock.rttMs,
      driftMs: this.lastDrift,
      rate: this.rate,
      playing: !!this.anchor && this.anchor.playing,
      uri: this.anchor ? this.anchor.track_uri : null,
      clockSamples: this.clock.sampleCount,
    };
  }

  dispose() {
    this.stopDrift();
    this.clock.stop();
  }
}
