/** Newline-delimited JSON. Output is pure ASCII (non-ASCII escaped) so multi-byte characters
 *  can never be split across TCP chunks. */
export function encodeLine(msg: any): string {
  return (
    JSON.stringify(msg).replace(
      /[\u0080-\uffff]/g,
      (c) => '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4)
    ) + '\n'
  );
}

export class LineParser {
  private buf = '';
  push(chunk: any): any[] {
    this.buf += typeof chunk === 'string' ? chunk : chunk.toString();
    const out: any[] = [];
    let i: number;
    while ((i = this.buf.indexOf('\n')) >= 0) {
      const line = this.buf.slice(0, i).trim();
      this.buf = this.buf.slice(i + 1);
      if (line) {
        try {
          out.push(JSON.parse(line));
        } catch {
          /* ignore garbage */
        }
      }
    }
    return out;
  }
}
