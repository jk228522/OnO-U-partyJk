import TcpSocket from 'react-native-tcp-socket';
import { SYNC_CONFIG } from '../sync/protocol';
import { encodeLine, LineParser } from './framing';
import { GuestTransport, HostTransport } from './types';

/** OFFLINE mode: host runs a TCP server, guests connect to <host ip>:8765 over the same hotspot/Wi-Fi. */
export class TcpHostTransport implements HostTransport {
  private server: any = null;
  private sockets = new Map<string, any>();
  private counter = 0;
  private joinCbs: ((id: string) => void)[] = [];
  private leaveCbs: ((id: string) => void)[] = [];
  private msgCbs: ((id: string, msg: any) => void)[] = [];
  private closeCbs: ((reason: string) => void)[] = [];
  private closedByUs = false;

  onGuestJoin(cb: (id: string) => void) { this.joinCbs.push(cb); }
  onGuestLeave(cb: (id: string) => void) { this.leaveCbs.push(cb); }
  onMessage(cb: (id: string, msg: any) => void) { this.msgCbs.push(cb); }
  onClose(cb: (reason: string) => void) { this.closeCbs.push(cb); }

  start(port: number = SYNC_CONFIG.TCP_PORT): Promise<void> {
    return new Promise((resolve, reject) => {
      let settled = false;
      const server = TcpSocket.createServer((socket: any) => this.accept(socket));
      this.server = server;
      server.on('error', (e: any) => {
        if (!settled) {
          settled = true;
          reject(new Error('Cannot start local server: ' + String((e && e.message) || e)));
        } else if (!this.closedByUs) {
          this.closeCbs.forEach((cb) => cb('Local server error'));
        }
      });
      server.listen({ port, host: '0.0.0.0', reuseAddress: true }, () => {
        if (!settled) {
          settled = true;
          resolve();
        }
      });
    });
  }

  private accept(socket: any) {
    const id = 'g' + ++this.counter;
    const parser = new LineParser();
    this.sockets.set(id, socket);
    try { socket.setNoDelay && socket.setNoDelay(true); } catch {}
    socket.on('data', (data: any) => {
      for (const m of parser.push(data)) this.msgCbs.forEach((cb) => cb(id, m));
    });
    let left = false;
    const gone = () => {
      if (left) return;
      left = true;
      this.sockets.delete(id);
      this.leaveCbs.forEach((cb) => cb(id));
    };
    socket.on('close', gone);
    socket.on('error', gone);
    this.joinCbs.forEach((cb) => cb(id));
  }

  send(id: string, msg: any) {
    const s = this.sockets.get(id);
    if (!s) return;
    try { s.write(encodeLine(msg)); } catch {}
  }

  broadcast(msg: any) {
    const line = encodeLine(msg);
    this.sockets.forEach((s) => {
      try { s.write(line); } catch {}
    });
  }

  close() {
    this.closedByUs = true;
    this.sockets.forEach((s) => {
      try { s.destroy(); } catch {}
    });
    this.sockets.clear();
    try { this.server && this.server.close(); } catch {}
  }
}

export class TcpGuestTransport implements GuestTransport {
  private socket: any = null;
  private queue: any[] = [];
  private msgCb: ((m: any) => void) | null = null;
  private closeCbs: ((reason: string) => void)[] = [];
  private closedByUs = false;

  constructor(private host: string, private port: number = SYNC_CONFIG.TCP_PORT) {}

  onMessage(cb: (m: any) => void) {
    this.msgCb = cb;
    const pending = this.queue;
    this.queue = [];
    pending.forEach(cb);
  }
  onClose(cb: (reason: string) => void) { this.closeCbs.push(cb); }

  connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      let settled = false;
      const parser = new LineParser();
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        try { this.socket && this.socket.destroy(); } catch {}
        reject(new Error('Timeout: host not reachable. Check the IP and that both phones are on the same hotspot/Wi-Fi.'));
      }, 10000);
      const socket = TcpSocket.createConnection({ host: this.host.trim(), port: this.port }, () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve();
      });
      this.socket = socket;
      try { socket.setNoDelay && socket.setNoDelay(true); } catch {}
      socket.on('data', (data: any) => {
        for (const m of parser.push(data)) {
          if (this.msgCb) this.msgCb(m);
          else this.queue.push(m);
        }
      });
      socket.on('error', (e: any) => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          reject(new Error('Connection failed: ' + String((e && e.message) || e)));
        } else if (!this.closedByUs) {
          this.closeCbs.forEach((cb) => cb('Connection error'));
        }
      });
      socket.on('close', () => {
        if (settled && !this.closedByUs) this.closeCbs.forEach((cb) => cb('Disconnected from host'));
      });
    });
  }

  send(msg: any) {
    try { this.socket && this.socket.write(encodeLine(msg)); } catch {}
  }

  close() {
    this.closedByUs = true;
    try { this.socket && this.socket.destroy(); } catch {}
  }
}
