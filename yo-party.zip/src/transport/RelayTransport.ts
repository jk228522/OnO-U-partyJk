import { GuestTransport, HostTransport } from './types';

export function toWsUrl(u: string): string {
  let s = u.trim();
  if (/^https:\/\//i.test(s)) s = 'wss://' + s.slice(8);
  else if (/^http:\/\//i.test(s)) s = 'ws://' + s.slice(7);
  else if (!/^wss?:\/\//i.test(s)) s = 'wss://' + s;
  return s.replace(/\/+$/, '');
}

const CONNECT_TIMEOUT_MS = 60000; // free hosting can take ~1 min to wake up

/** ONLINE mode: host creates a party code on the relay server, guests join by code. */
export class RelayHostTransport implements HostTransport {
  private ws: WebSocket | null = null;
  private joinCbs: ((id: string) => void)[] = [];
  private leaveCbs: ((id: string) => void)[] = [];
  private msgCbs: ((id: string, msg: any) => void)[] = [];
  private closeCbs: ((reason: string) => void)[] = [];
  private closedByUs = false;
  code = '';

  constructor(private url: string) {}

  onGuestJoin(cb: (id: string) => void) { this.joinCbs.push(cb); }
  onGuestLeave(cb: (id: string) => void) { this.leaveCbs.push(cb); }
  onMessage(cb: (id: string, msg: any) => void) { this.msgCbs.push(cb); }
  onClose(cb: (reason: string) => void) { this.closeCbs.push(cb); }

  start(): Promise<string> {
    return new Promise((resolve, reject) => {
      let settled = false;
      const fail = (msg: string) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(new Error(msg));
      };
      const timer = setTimeout(() => {
        try { this.ws && this.ws.close(); } catch {}
        fail('Relay server timeout (it may be waking up - try again)');
      }, CONNECT_TIMEOUT_MS);
      const ws = new WebSocket(toWsUrl(this.url));
      this.ws = ws;
      ws.onopen = () => ws.send(JSON.stringify({ t: 'create' }));
      ws.onmessage = (ev: any) => {
        let m: any;
        try { m = JSON.parse(String(ev.data)); } catch { return; }
        switch (m.t) {
          case 'created':
            this.code = m.code;
            if (!settled) {
              settled = true;
              clearTimeout(timer);
              resolve(m.code);
            }
            break;
          case 'guest_join':
            this.joinCbs.forEach((cb) => cb(m.id));
            break;
          case 'guest_leave':
            this.leaveCbs.forEach((cb) => cb(m.id));
            break;
          case 'from':
            this.msgCbs.forEach((cb) => cb(m.from, m.data));
            break;
        }
      };
      ws.onerror = () => fail('Cannot reach relay server. Check the URL in settings.');
      ws.onclose = () => {
        if (!settled) fail('Relay closed the connection');
        else if (!this.closedByUs) this.closeCbs.forEach((cb) => cb('Relay disconnected'));
      };
    });
  }

  send(id: string, msg: any) {
    try { this.ws && this.ws.send(JSON.stringify({ t: 'to', to: id, data: msg })); } catch {}
  }

  broadcast(msg: any) {
    try { this.ws && this.ws.send(JSON.stringify({ t: 'to', to: '*', data: msg })); } catch {}
  }

  close() {
    this.closedByUs = true;
    try { this.ws && this.ws.close(); } catch {}
  }
}

export class RelayGuestTransport implements GuestTransport {
  private ws: WebSocket | null = null;
  private queue: any[] = [];
  private msgCb: ((m: any) => void) | null = null;
  private closeCbs: ((reason: string) => void)[] = [];
  private closedByUs = false;

  constructor(private url: string, private code: string) {}

  onMessage(cb: (m: any) => void) {
    this.msgCb = cb;
    const pending = this.queue;
    this.queue = [];
    pending.forEach(cb);
  }
  onClose(cb: (reason: string) => void) { this.closeCbs.push(cb); }

  connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      let settled = false;
      const fail = (msg: string) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        try { this.ws && this.ws.close(); } catch {}
        reject(new Error(msg));
      };
      const timer = setTimeout(
        () => fail('Relay server timeout (it may be waking up - try again)'),
        CONNECT_TIMEOUT_MS
      );
      const ws = new WebSocket(toWsUrl(this.url));
      this.ws = ws;
      ws.onopen = () => ws.send(JSON.stringify({ t: 'join', code: this.code }));
      ws.onmessage = (ev: any) => {
        let m: any;
        try { m = JSON.parse(String(ev.data)); } catch { return; }
        if (m.t === 'joined') {
          if (!settled) {
            settled = true;
            clearTimeout(timer);
            resolve();
          }
        } else if (m.t === 'error') {
          fail(m.reason || 'Join failed');
        } else if (m.t === 'data') {
          if (this.msgCb) this.msgCb(m.data);
          else this.queue.push(m.data);
        } else if (m.t === 'host_left') {
          this.closeCbs.forEach((cb) => cb('Host ended the party'));
        }
      };
      ws.onerror = () => fail('Cannot reach relay server. Check the URL in settings.');
      ws.onclose = () => {
        if (!settled) fail('Relay closed the connection');
        else if (!this.closedByUs) this.closeCbs.forEach((cb) => cb('Disconnected from relay'));
      };
    });
  }

  send(msg: any) {
    try { this.ws && this.ws.send(JSON.stringify({ t: 'data', data: msg })); } catch {}
  }

  close() {
    this.closedByUs = true;
    try { this.ws && this.ws.close(); } catch {}
  }
}
