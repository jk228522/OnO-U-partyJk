/** Both transports (offline TCP hotspot / online relay) expose exactly this interface,
 *  so MasterSyncEngine / GuestSyncEngine contain ONE shared sync logic. */
export interface HostTransport {
  onGuestJoin(cb: (guestId: string) => void): void;
  onGuestLeave(cb: (guestId: string) => void): void;
  onMessage(cb: (guestId: string, msg: any) => void): void;
  onClose(cb: (reason: string) => void): void;
  send(guestId: string, msg: any): void;
  broadcast(msg: any): void;
  close(): void;
}

export interface GuestTransport {
  onMessage(cb: (msg: any) => void): void;
  onClose(cb: (reason: string) => void): void;
  send(msg: any): void;
  connect(): Promise<void>;
  close(): void;
}
