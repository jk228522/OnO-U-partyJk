import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { C } from '../theme';

export default function GuestList({ ids }: { ids: string[] }) {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>Connected guests ({ids.length})</Text>
      {ids.length === 0 ? (
        <Text style={styles.dim}>Waiting for guests to join…</Text>
      ) : (
        ids.map((id, i) => (
          <Text key={id} style={styles.item}>🎧 Guest {i + 1}  <Text style={styles.dim}>({id})</Text></Text>
        ))
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: C.card, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: C.border },
  title: { color: C.text, fontWeight: '700', marginBottom: 6 },
  item: { color: C.text, paddingVertical: 2 },
  dim: { color: C.dim },
});
