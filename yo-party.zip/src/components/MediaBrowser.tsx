import React, { useRef, useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';
import WebView from 'react-native-webview';
import type { WebViewMessageEvent, WebViewNavigation } from 'react-native-webview';
import { INJECTED_JS, PAUSE_ALL_JS } from '../browser/injected';
import { C } from '../theme';

interface Props {
  /** Total height of the browser block (nav bar + WebView). Host screen passes ~65% of the screen. */
  height: number;
  onMediaDetected: (uri: string, title: string) => void;
  onClose: () => void;
}

const START_URL = 'https://www.google.com';

function normalize(input: string): string {
  const t = input.trim();
  if (!t) return START_URL;
  if (/^https?:\/\//i.test(t)) return t;
  if (t.indexOf(' ') === -1 && t.indexOf('.') > 0) return 'https://' + t;
  return 'https://www.google.com/search?q=' + encodeURIComponent(t);
}

export default function MediaBrowser({ height, onMediaDetected, onClose }: Props) {
  const web = useRef<WebView>(null);
  const [source, setSource] = useState({ uri: START_URL });
  const [address, setAddress] = useState(START_URL);
  const [canBack, setCanBack] = useState(false);
  const [canFwd, setCanFwd] = useState(false);
  const [status, setStatus] = useState('Open a page with a direct audio link (.mp3 / .m4a / .aac / .m3u8)');
  const lastHandoff = useRef({ src: '', at: 0 });

  const onNav = (n: WebViewNavigation) => {
    setCanBack(n.canGoBack);
    setCanFwd(n.canGoForward);
    if (n.url) setAddress(n.url);
  };

  const onMessage = (e: WebViewMessageEvent) => {
    let m: any;
    try {
      m = JSON.parse(e.nativeEvent.data);
    } catch {
      return;
    }
    if (!m || m.kind !== 'media') return;
    const src = String(m.src || '');
    const direct = /^https?:\/\//i.test(src);

    if (m.type === 'timeupdate' || m.type === 'pause') {
      if (direct) setStatus(`${m.type}: ${Math.floor(m.currentTime)}s / ${Math.floor(m.duration)}s`);
      return;
    }
    const wantsHandoff = m.type === 'play' || (m.type === 'srcchange' && m.paused === false);
    if (!wantsHandoff || !src) return;

    if (!direct) {
      // blob:/mediastream: (YouTube, Spotify Web, SoundCloud use MSE/DRM) cannot be re-streamed.
      if (m.type === 'play') {
        setStatus('This site streams through a protected/blob player - it can play here, but cannot be shared with guests. Use a direct audio URL.');
      }
      return;
    }
    const now = Date.now();
    if (lastHandoff.current.src === src && now - lastHandoff.current.at < 1500) return;
    lastHandoff.current = { src, at: now };
    web.current?.injectJavaScript(PAUSE_ALL_JS);
    setStatus('Sent to party: ' + (m.title || src));
    onMediaDetected(src, String(m.title || ''));
  };

  const go = () => {
    const url = normalize(address);
    setAddress(url);
    setSource({ uri: url });
  };

  return (
    <View style={[styles.wrap, { height }]}>
      <View style={styles.nav}>
        <Pressable onPress={() => web.current?.goBack()} disabled={!canBack} style={[styles.btn, !canBack && styles.off]}>
          <Text style={styles.btnTxt}>◀</Text>
        </Pressable>
        <Pressable onPress={() => web.current?.goForward()} disabled={!canFwd} style={[styles.btn, !canFwd && styles.off]}>
          <Text style={styles.btnTxt}>▶</Text>
        </Pressable>
        <Pressable onPress={() => web.current?.reload()} style={styles.btn}>
          <Text style={styles.btnTxt}>⟳</Text>
        </Pressable>
        <TextInput
          style={styles.input}
          value={address}
          onChangeText={setAddress}
          onSubmitEditing={go}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="url"
          returnKeyType="go"
          selectTextOnFocus
        />
        <Pressable onPress={onClose} style={[styles.btn, styles.close]}>
          <Text style={styles.btnTxt}>✕</Text>
        </Pressable>
      </View>
      <Text style={styles.status} numberOfLines={2}>{status}</Text>
      <WebView
        ref={web}
        source={source}
        style={styles.web}
        originWhitelist={['*']}
        javaScriptEnabled
        domStorageEnabled
        setSupportMultipleWindows={false}
        allowsInlineMediaPlayback
        mixedContentMode="always"
        injectedJavaScriptBeforeContentLoaded={INJECTED_JS}
        injectedJavaScriptForMainFrameOnly={false}
        onMessage={onMessage}
        onNavigationStateChange={onNav}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { backgroundColor: C.card, borderBottomWidth: 1, borderColor: C.border },
  nav: { flexDirection: 'row', alignItems: 'center', padding: 6, gap: 6 },
  btn: { width: 36, height: 36, borderRadius: 8, backgroundColor: C.border, alignItems: 'center', justifyContent: 'center' },
  close: { backgroundColor: C.bad },
  off: { opacity: 0.35 },
  btnTxt: { color: C.text, fontSize: 16 },
  input: { flex: 1, height: 36, borderRadius: 8, paddingHorizontal: 10, backgroundColor: C.bg, color: C.text, fontSize: 13 },
  status: { color: C.dim, fontSize: 11, paddingHorizontal: 8, paddingBottom: 4 },
  web: { flex: 1, backgroundColor: '#000' },
});
