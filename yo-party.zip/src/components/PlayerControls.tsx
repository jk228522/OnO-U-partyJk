import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { fmt } from '../utils/time';
import { C } from '../theme';

interface Props {
  playing: boolean;
  positionMs: number;
  durationMs: number;
  disabled: boolean;
  onToggle: () => void;
  onBack: () => void;
  onForward: () => void;
}

export default function PlayerControls({ playing, positionMs, durationMs, disabled, onToggle, onBack, onForward }: Props) {
  const pct = durationMs > 0 ? Math.min(1, positionMs / durationMs) : 0;
  return (
    <View style={styles.card}>
      <View style={styles.bar}>
        <View style={[styles.fill, { width: `${pct * 100}%` }]} />
      </View>
      <Text style={styles.time}>{fmt(positionMs)} / {fmt(durationMs)}</Text>
      <View style={styles.row}>
        <Pressable disabled={disabled} onPress={onBack} style={[styles.btn, disabled && styles.off]}>
          <Text style={styles.txt}>⏪ 10s</Text>
        </Pressable>
        <Pressable disabled={disabled} onPress={onToggle} style={[styles.btn, styles.main, disabled && styles.off]}>
          <Text style={styles.txt}>{playing ? '⏸ Pause' : '▶ Play'}</Text>
        </Pressable>
        <Pressable disabled={disabled} onPress={onForward} style={[styles.btn, disabled && styles.off]}>
          <Text style={styles.txt}>10s ⏩</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: C.card, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: C.border },
  bar: { height: 4, borderRadius: 2, backgroundColor: C.border, overflow: 'hidden' },
  fill: { height: 4, backgroundColor: C.accent },
  time: { color: C.dim, fontSize: 12, textAlign: 'center', marginVertical: 8 },
  row: { flexDirection: 'row', gap: 8 },
  btn: { flex: 1, height: 44, borderRadius: 10, backgroundColor: C.border, alignItems: 'center', justifyContent: 'center' },
  main: { backgroundColor: C.accent, flex: 1.4 },
  off: { opacity: 0.4 },
  txt: { color: C.text, fontWeight: '600' },
});
