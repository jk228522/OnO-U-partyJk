export const C = {
  bg: '#0d0f14',
  card: '#181b23',
  border: '#2a2f3b',
  text: '#f2f4f8',
  dim: '#8b93a5',
  accent: '#7c5cff',
  good: '#31c48d',
  bad: '#f05252',
  warn: '#f5a524',
};
