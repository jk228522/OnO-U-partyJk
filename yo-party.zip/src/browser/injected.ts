/**
 * MODULE 2 - JS bridge injected into every frame of the WebView (before page scripts run).
 * Detects play / pause / timeupdate / src changes on HTML5 <audio>/<video> (including detached
 * `new Audio()` objects, via prototype patching) and posts them to React Native.
 * When a DIRECT http(s) source is found, the page's own playback is blocked so that only the
 * native player (which is the one broadcast to guests) makes sound on the host.
 */
export const INJECTED_JS = `
(function () {
  if (window.__yoBridgeInstalled) return;
  window.__yoBridgeInstalled = true;
  window.__yoBlock = true;
  var lastTimeSent = 0;

  function post(o) {
    try { window.ReactNativeWebView.postMessage(JSON.stringify(o)); } catch (e) {}
  }
  function isDirect(s) {
    s = s || '';
    return s.indexOf('http://') === 0 || s.indexOf('https://') === 0;
  }
  function report(type, el) {
    try {
      var src = el.currentSrc || el.src || '';
      post({
        kind: 'media',
        type: type,
        src: src,
        currentTime: el.currentTime || 0,
        duration: isFinite(el.duration) ? el.duration : 0,
        paused: !!el.paused,
        title: document.title || '',
        page: location.href
      });
    } catch (e) {}
  }

  var origPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function () {
    var src = this.currentSrc || this.src || '';
    report('play', this);
    if (window.__yoBlock && isDirect(src)) {
      try { this.pause(); } catch (e) {}
      return Promise.resolve();
    }
    return origPlay.apply(this, arguments);
  };

  try {
    var d = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'src');
    if (d && d.set) {
      Object.defineProperty(HTMLMediaElement.prototype, 'src', {
        get: d.get,
        set: function (v) { d.set.call(this, v); report('srcchange', this); },
        configurable: true
      });
    }
  } catch (e) {}

  ['play', 'pause', 'timeupdate', 'loadstart'].forEach(function (ev) {
    document.addEventListener(ev, function (e) {
      var el = e.target;
      if (!el || !el.tagName) return;
      var t = String(el.tagName).toLowerCase();
      if (t !== 'audio' && t !== 'video') return;
      if (ev === 'timeupdate') {
        var n = Date.now();
        if (n - lastTimeSent < 1000) return;
        lastTimeSent = n;
      }
      report(ev === 'loadstart' ? 'srcchange' : ev, el);
    }, true);
  });
})();
true;
`;

export const PAUSE_ALL_JS = `
(function () {
  try {
    var els = document.querySelectorAll('audio,video');
    for (var i = 0; i < els.length; i++) { try { els[i].pause(); } catch (e) {} }
  } catch (e) {}
})();
true;
`;
