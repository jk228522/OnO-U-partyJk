import { Audio } from 'expo-av';

/** Thin wrapper over expo-av so the sync engines have one small, predictable surface. */
export class AudioPlayer {
  private sound: Audio.Sound | null = null;
  private token = 0;
  durationMs = 0;
  onFinish?: () => void;

  async init() {
    await Audio.setAudioModeAsync({
      playsInSilentModeIOS: true,
      staysActiveInBackground: true,
      shouldDuckAndroid: false,
      playThroughEarpieceAndroid: false,
    });
  }

  async load(uri: string) {
    await this.unload();
    const myToken = this.token;
    const { sound, status } = await Audio.Sound.createAsync(
      { uri },
      { shouldPlay: false, progressUpdateIntervalMillis: 250, rate: 1.0, shouldCorrectPitch: true },
      (s: any) => {
        if (myToken !== this.token) return;
        if (s && s.isLoaded) {
          if (s.durationMillis) this.durationMs = s.durationMillis;
          if (s.didJustFinish) this.onFinish?.();
        }
      }
    );
    if (myToken !== this.token) {
      try {
        await sound.unloadAsync();
      } catch {}
      return;
    }
    this.sound = sound;
    this.durationMs = (status as any).durationMillis ?? 0;
  }

  async unload() {
    this.token++;
    const s = this.sound;
    this.sound = null;
    this.durationMs = 0;
    if (s) {
      try {
        await s.unloadAsync();
      } catch {}
    }
  }

  private need(): Audio.Sound {
    if (!this.sound) throw new Error('No track loaded');
    return this.sound;
  }

  /** Seek + start in ONE native call (lowest latency). */
  async playAt(positionMs: number, rate = 1): Promise<any> {
    return this.need().setStatusAsync({
      positionMillis: Math.max(0, Math.round(positionMs)),
      shouldPlay: true,
      rate,
      shouldCorrectPitch: true,
    });
  }

  async pauseAt(positionMs?: number): Promise<any> {
    const s: any = { shouldPlay: false, rate: 1 };
    if (positionMs !== undefined) s.positionMillis = Math.max(0, Math.round(positionMs));
    return this.need().setStatusAsync(s);
  }

  async setPosition(positionMs: number): Promise<any> {
    return this.need().setPositionAsync(Math.max(0, Math.round(positionMs)));
  }

  async setRate(rate: number): Promise<any> {
    return this.need().setRateAsync(rate, true);
  }

  async getStatus(): Promise<any | null> {
    if (!this.sound) return null;
    try {
      return await this.sound.getStatusAsync();
    } catch {
      return null;
    }
  }
}
