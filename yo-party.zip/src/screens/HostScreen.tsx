import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TextInput, Pressable, useWindowDimensions, Platform, StatusBar,
} from 'react-native';
import * as Network from 'expo-network';
import { AudioPlayer } from '../audio/AudioPlayer';
import { MasterSyncEngine } from '../sync/MasterSyncEngine';
import { SyncPayload, SYNC_CONFIG } from '../sync/protocol';
import { TcpHostTransport } from '../transport/TcpTransport';
import { RelayHostTransport } from '../transport/RelayTransport';
import { HostTransport } from '../transport/types';
import MediaBrowser from '../components/MediaBrowser';
import PlayerControls from '../components/PlayerControls';
import GuestList from '../components/GuestList';
import { C } from '../theme';
import type { Mode } from './HomeScreen';

interface Props {
  mode: Mode;
  relayUrl: string;
  onLeave: () => void;
}

export default function HostScreen({ mode, relayUrl, onLeave }: Props) {
  const { height } = useWindowDimensions();
  const browserHeight = Math.round(height * 0.65); // 60-70% of the screen
  const topPad = Platform.OS === 'android' ? StatusBar.currentHeight || 24 : 0;

  const engineRef = useRef<MasterSyncEngine | null>(null);
  const playerRef = useRef<AudioPlayer | null>(null);
  const transportRef = useRef<HostTransport | null>(null);

  const [phase, setPhase] = useState<'starting' | 'ready' | 'error'>('starting');
  const [info, setInfo] = useState('');
  const [manualIp, setManualIp] = useState('');
  const [guests, setGuests] = useState<string[]>([]);
  const [snapshot, setSnapshot] = useState<SyncPayload | null>(null);
  const [positionMs, setPositionMs] = useState(0);
  const [durationMs, setDurationMs] = useState(0);
  const [notice, setNotice] = useState('');
  const [browserOpen, setBrowserOpen] = useState(true);
  const [urlInput, setUrlInput] = useState('');

  useEffect(() => {
    let cancelled = false;
    const player = new AudioPlayer();
    playerRef.current = player;

    (async () => {
      try {
        await player.init();
        let transport: HostTransport;
        if (mode === 'offline') {
          const t = new TcpHostTransport();
          transport = t;
          transportRef.current = t;
          const engine = new MasterSyncEngine(t, player);
          engineRef.current = engine;
          wire(engine, t);
          await t.start();
          let ip = '';
          try {
            ip = await Network.getIpAddressAsync();
          } catch {}
          if (cancelled) return;
          setManualIp(ip && ip !== '0.0.0.0' ? ip : '192.168.43.1');
          setInfo(`${SYNC_CONFIG.TCP_PORT}`);
        } else {
          const t = new RelayHostTransport(relayUrl);
          transport = t;
          transportRef.current = t;
          const engine = new MasterSyncEngine(t, player);
          engineRef.current = engine;
          wire(engine, t);
          const code = await t.start();
          if (cancelled) return;
          setInfo(code);
        }
        if (!cancelled) setPhase('ready');
      } catch (e: any) {
        if (!cancelled) {
          setNotice(String((e && e.message) || e));
          setPhase('error');
        }
      }
    })();

    function wire(engine: MasterSyncEngine, t: HostTransport) {
      engine.onGuestsChanged = (ids) => !cancelled && setGuests(ids);
      engine.onStateChanged = (s) => !cancelled && setSnapshot(s);
      engine.onError = (m) => !cancelled && setNotice(m);
      t.onClose((reason) => {
        if (!cancelled) {
          setNotice(reason);
          setPhase('error');
        }
      });
    }

    const poll = setInterval(async () => {
      const st = await player.getStatus();
      if (!cancelled && st && st.isLoaded) {
        setPositionMs(st.positionMillis || 0);
        setDurationMs(st.durationMillis || 0);
      }
    }, 500);

    return () => {
      cancelled = true;
      clearInterval(poll);
      engineRef.current?.dispose();
      transportRef.current?.close();
      player.unload();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const playUri = (uri: string) => {
    const u = uri.trim();
    if (!u) return;
    setNotice('');
    engineRef.current?.playTrack(u);
  };

  const ready = phase === 'ready' && !!engineRef.current;
  const hasTrack = !!snapshot;

  return (
    <View style={[styles.root, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Host · {mode === 'offline' ? 'Offline' : 'Online'}</Text>
        {!browserOpen && (
          <Pressable style={styles.smallBtn} onPress={() => setBrowserOpen(true)}>
            <Text style={styles.smallTxt}>🌐 Browser</Text>
          </Pressable>
        )}
        <Pressable style={[styles.smallBtn, { backgroundColor: C.bad }]} onPress={onLeave}>
          <Text style={styles.smallTxt}>Leave</Text>
        </Pressable>
      </View>

      {browserOpen && (
        <MediaBrowser
          height={browserHeight}
          onMediaDetected={(uri) => playUri(uri)}
          onClose={() => setBrowserOpen(false)}
        />
      )}

      <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">
        <View style={styles.card}>
          {phase === 'starting' && <Text style={styles.dim}>Starting… (online mode may take up to a minute if the server is asleep)</Text>}
          {phase === 'error' && <Text style={{ color: C.bad }}>{notice || 'Something went wrong'}</Text>}
          {phase === 'ready' && mode === 'online' && (
            <>
              <Text style={styles.dim}>Party code - tell your guests</Text>
              <Text style={styles.code}>{info}</Text>
            </>
          )}
          {phase === 'ready' && mode === 'offline' && (
            <>
              <Text style={styles.dim}>Guests enter this host IP (port {info}). Hotspot owner is usually 192.168.43.1</Text>
              <TextInput
                style={styles.ipInput}
                value={manualIp}
                onChangeText={setManualIp}
                keyboardType="numbers-and-punctuation"
                autoCapitalize="none"
              />
            </>
          )}
        </View>

        <View style={styles.card}>
          <Text style={styles.label}>Play a direct audio URL</Text>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <TextInput
              style={styles.urlInput}
              value={urlInput}
              onChangeText={setUrlInput}
              placeholder="https://…/song.mp3"
              placeholderTextColor={C.dim}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
            />
            <Pressable style={[styles.smallBtn, !ready && { opacity: 0.4 }]} disabled={!ready} onPress={() => playUri(urlInput)}>
              <Text style={styles.smallTxt}>Play</Text>
            </Pressable>
          </View>
          {!!snapshot && <Text style={styles.now} numberOfLines={1}>Now: {snapshot.track_uri}</Text>}
        </View>

        <PlayerControls
          playing={!!snapshot?.playing}
          positionMs={positionMs}
          durationMs={durationMs}
          disabled={!ready || !hasTrack}
          onToggle={() => (snapshot?.playing ? engineRef.current?.pause() : engineRef.current?.resume())}
          onBack={() => engineRef.current?.seekBy(-10000)}
          onForward={() => engineRef.current?.seekBy(10000)}
        />

        <GuestList ids={guests} />
        {phase === 'ready' && !!notice && <Text style={{ color: C.warn }}>{notice}</Text>}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 6, gap: 8 },
  title: { flex: 1, color: C.text, fontWeight: '800', fontSize: 16 },
  smallBtn: { backgroundColor: C.accent, borderRadius: 8, paddingHorizontal: 12, height: 36, alignItems: 'center', justifyContent: 'center' },
  smallTxt: { color: '#fff', fontWeight: '700' },
  body: { padding: 12, gap: 12 },
  card: { backgroundColor: C.card, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: C.border, gap: 6 },
  dim: { color: C.dim, fontSize: 12 },
  code: { color: C.text, fontSize: 40, fontWeight: '800', letterSpacing: 6, textAlign: 'center' },
  ipInput: { color: C.text, fontSize: 22, fontWeight: '700', backgroundColor: C.bg, borderRadius: 8, padding: 8, textAlign: 'center' },
  label: { color: C.text, fontWeight: '700' },
  urlInput: { flex: 1, height: 36, color: C.text, backgroundColor: C.bg, borderRadius: 8, paddingHorizontal: 10 },
  now: { color: C.dim, fontSize: 11 },
});
