import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, Platform, StatusBar, ScrollView } from 'react-native';
import { AudioPlayer } from '../audio/AudioPlayer';
import { GuestSyncEngine, GuestStats } from '../sync/GuestSyncEngine';
import { TcpGuestTransport } from '../transport/TcpTransport';
import { RelayGuestTransport } from '../transport/RelayTransport';
import { GuestTransport } from '../transport/types';
import { C } from '../theme';
import type { Mode } from './HomeScreen';

interface Props {
  mode: Mode;
  relayUrl: string;
  onLeave: () => void;
}

export default function GuestScreen({ mode, relayUrl, onLeave }: Props) {
  const topPad = Platform.OS === 'android' ? StatusBar.currentHeight || 24 : 0;
  const engineRef = useRef<GuestSyncEngine | null>(null);
  const playerRef = useRef<AudioPlayer | null>(null);
  const transportRef = useRef<GuestTransport | null>(null);
  const mounted = useRef(true);

  const [target, setTarget] = useState(mode === 'offline' ? '192.168.43.1' : '');
  const [phase, setPhase] = useState<'form' | 'connecting' | 'connected' | 'closed'>('form');
  const [error, setError] = useState('');
  const [stats, setStats] = useState<GuestStats | null>(null);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      engineRef.current?.dispose();
      transportRef.current?.close();
      playerRef.current?.unload();
    };
  }, []);

  useEffect(() => {
    if (phase !== 'connected') return;
    const id = setInterval(() => {
      if (engineRef.current) setStats(engineRef.current.getStats());
    }, 400);
    return () => clearInterval(id);
  }, [phase]);

  const connect = async () => {
    const value = target.trim();
    if (!value) return;
    setError('');
    setPhase('connecting');
    try {
      const player = new AudioPlayer();
      await player.init();
      playerRef.current = player;
      const t: GuestTransport =
        mode === 'offline' ? new TcpGuestTransport(value) : new RelayGuestTransport(relayUrl, value.toUpperCase());
      transportRef.current = t;
      const engine = new GuestSyncEngine(t, player);
      engine.onError = (m) => mounted.current && setError(m);
      engineRef.current = engine;
      t.onClose((reason) => {
        if (!mounted.current) return;
        setError(reason);
        setPhase('closed');
        engine.dispose();
      });
      await t.connect();
      engine.start();
      if (mounted.current) setPhase('connected');
    } catch (e: any) {
      engineRef.current?.dispose();
      transportRef.current?.close();
      playerRef.current?.unload();
      if (mounted.current) {
        setError(String((e && e.message) || e));
        setPhase('form');
      }
    }
  };

  const good = stats && Math.abs(stats.driftMs) <= 15;

  return (
    <View style={[styles.root, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Guest · {mode === 'offline' ? 'Offline' : 'Online'}</Text>
        <Pressable style={styles.leave} onPress={onLeave}>
          <Text style={styles.leaveTxt}>Leave</Text>
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">
        {(phase === 'form' || phase === 'connecting' || phase === 'closed') && (
          <View style={styles.card}>
            <Text style={styles.label}>{mode === 'offline' ? 'Host IP address' : 'Party code'}</Text>
            <TextInput
              style={styles.input}
              value={target}
              onChangeText={setTarget}
              placeholder={mode === 'offline' ? '192.168.43.1' : 'ABCDE'}
              placeholderTextColor={C.dim}
              autoCapitalize={mode === 'offline' ? 'none' : 'characters'}
              autoCorrect={false}
              keyboardType={mode === 'offline' ? 'numbers-and-punctuation' : 'default'}
            />
            <Pressable
              style={[styles.btn, phase === 'connecting' && { opacity: 0.5 }]}
              disabled={phase === 'connecting'}
              onPress={connect}
            >
              <Text style={styles.btnTxt}>{phase === 'connecting' ? 'Connecting…' : phase === 'closed' ? 'Reconnect' : 'Join party'}</Text>
            </Pressable>
            {phase === 'connecting' && <Text style={styles.dim}>Online mode: the server may need up to a minute to wake up.</Text>}
          </View>
        )}

        {phase === 'connected' && (
          <View style={styles.card}>
            <Text style={[styles.big, { color: C.good }]}>● Connected</Text>
            <Text style={styles.line}>{stats?.playing ? '▶ Playing in sync' : '⏸ Waiting for host to play'}</Text>
            {!!stats?.uri && <Text style={styles.dim} numberOfLines={2}>{stats.uri}</Text>}
            <View style={styles.grid}>
              <Stat label="Drift" value={`${(stats?.driftMs ?? 0).toFixed(0)} ms`} color={good ? C.good : C.warn} />
              <Stat label="Clock offset" value={`${(stats?.offsetMs ?? 0).toFixed(1)} ms`} />
              <Stat label="Round trip" value={`${(stats?.rttMs ?? 0).toFixed(1)} ms`} />
              <Stat label="Play rate" value={`${(stats?.rate ?? 1).toFixed(3)}x`} />
            </View>
          </View>
        )}

        {!!error && <Text style={{ color: C.bad }}>{error}</Text>}
      </ScrollView>
    </View>
  );
}

function Stat({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.dim}>{label}</Text>
      <Text style={[styles.statVal, color ? { color } : null]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  header: { flexDirection: 'row', alignItems: 'center', padding: 10 },
  title: { flex: 1, color: C.text, fontWeight: '800', fontSize: 16 },
  leave: { backgroundColor: C.bad, borderRadius: 8, paddingHorizontal: 12, height: 36, alignItems: 'center', justifyContent: 'center' },
  leaveTxt: { color: '#fff', fontWeight: '700' },
  body: { padding: 12, gap: 12 },
  card: { backgroundColor: C.card, borderRadius: 12, padding: 14, borderWidth: 1, borderColor: C.border, gap: 8 },
  label: { color: C.text, fontWeight: '700' },
  input: { color: C.text, fontSize: 22, fontWeight: '700', backgroundColor: C.bg, borderRadius: 8, padding: 10, textAlign: 'center' },
  btn: { backgroundColor: C.accent, borderRadius: 10, height: 46, alignItems: 'center', justifyContent: 'center' },
  btnTxt: { color: '#fff', fontWeight: '700', fontSize: 15 },
  big: { fontSize: 20, fontWeight: '800' },
  line: { color: C.text, fontSize: 15 },
  dim: { color: C.dim, fontSize: 12 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 6 },
  stat: { width: '48%', backgroundColor: C.bg, borderRadius: 8, padding: 10 },
  statVal: { color: C.text, fontSize: 18, fontWeight: '700' },
});
