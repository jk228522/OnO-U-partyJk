import React from 'react';
import { View, Text, TextInput, Pressable, ScrollView, StyleSheet } from 'react-native';
import { C } from '../theme';

export type Mode = 'offline' | 'online';

interface Props {
  relayUrl: string;
  setRelayUrl: (u: string) => void;
  onHost: (m: Mode) => void;
  onGuest: (m: Mode) => void;
}

export default function HomeScreen({ relayUrl, setRelayUrl, onHost, onGuest }: Props) {
  return (
    <ScrollView contentContainerStyle={styles.root} keyboardShouldPersistTaps="handled">
      <Text style={styles.logo}>🎉 Yo Party</Text>
      <Text style={styles.sub}>One phone plays, every phone follows - in sync.</Text>

      <Text style={styles.h}>Host</Text>
      <Pressable style={styles.btn} onPress={() => onHost('offline')}>
        <Text style={styles.btnTxt}>📶 Host · Offline (hotspot / Wi-Fi)</Text>
      </Pressable>
      <Pressable style={styles.btn} onPress={() => onHost('online')}>
        <Text style={styles.btnTxt}>🌐 Host · Online (party code)</Text>
      </Pressable>

      <Text style={styles.h}>Guest</Text>
      <Pressable style={[styles.btn, styles.alt]} onPress={() => onGuest('offline')}>
        <Text style={styles.btnTxt}>📶 Join · Offline (host IP)</Text>
      </Pressable>
      <Pressable style={[styles.btn, styles.alt]} onPress={() => onGuest('online')}>
        <Text style={styles.btnTxt}>🌐 Join · Online (party code)</Text>
      </Pressable>

      <Text style={styles.h}>Relay server URL (online mode)</Text>
      <TextInput
        style={styles.input}
        value={relayUrl}
        onChangeText={setRelayUrl}
        autoCapitalize="none"
        autoCorrect={false}
        keyboardType="url"
      />
      <Text style={styles.hint}>Deploy the /server folder (Render / Railway / Fly) and paste its wss:// address here.</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { padding: 20, paddingTop: 40, gap: 10 },
  logo: { color: C.text, fontSize: 34, fontWeight: '800' },
  sub: { color: C.dim, marginBottom: 12 },
  h: { color: C.dim, fontWeight: '700', marginTop: 14, textTransform: 'uppercase', fontSize: 12 },
  btn: { backgroundColor: C.accent, borderRadius: 12, padding: 16 },
  alt: { backgroundColor: '#2c6e63' },
  btnTxt: { color: '#fff', fontWeight: '700', fontSize: 15 },
  input: { backgroundColor: C.card, color: C.text, borderRadius: 10, padding: 12, borderWidth: 1, borderColor: C.border },
  hint: { color: C.dim, fontSize: 12 },
});
