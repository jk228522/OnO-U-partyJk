// Monotonic, sub-millisecond clock. performance.now() is immune to wall-clock
// adjustments (NTP / user changing time) while the app is running. BASE anchors it
// to epoch time so the numbers look like Date.now() but with fractional ms.
const perf: any = (globalThis as any).performance;
const hasPerf = !!perf && typeof perf.now === 'function';
const BASE = Date.now() - (hasPerf ? perf.now() : 0);

export function nowMs(): number {
  return hasPerf ? BASE + perf.now() : Date.now();
}

export const sleep = (ms: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, Math.max(0, ms)));

export function fmt(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${r < 10 ? '0' : ''}${r}`;
}
