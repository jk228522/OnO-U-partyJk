// Change this to your deployed relay (see server/ folder). Users can also edit it inside the app.
export const DEFAULT_RELAY_URL = 'wss://yo-party-relay.onrender.com';
export const RELAY_STORAGE_KEY = 'yoparty:relayUrl';
