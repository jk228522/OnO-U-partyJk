# Yo Party

Synced party music: one Host phone plays, every Guest phone follows.

- Offline: TCP over the same hotspot/Wi-Fi (no internet)
- Online: party code through the relay in `server/`
- Same sync logic for both (`src/sync/*`)

## Structure
```
App.tsx, index.ts, app.json, package.json
src/sync/       protocol.ts  ClockSync.ts  MasterSyncEngine.ts  GuestSyncEngine.ts
src/transport/  TcpTransport.ts  RelayTransport.ts  framing.ts  types.ts
src/audio/      AudioPlayer.ts
src/browser/    injected.ts  (JS bridge for the WebView)
src/components/ MediaBrowser.tsx  PlayerControls.tsx  GuestList.tsx
src/screens/    HomeScreen.tsx  HostScreen.tsx  GuestScreen.tsx
server/         index.js  package.json   (deploy separately for online mode)
.github/workflows/build-apk.yml
```

## APK
Push to GitHub -> Actions -> "Build Android APK" -> download artifact `yo-party-apk`.

## Relay server (online mode)
Deploy `server/` on Render (Web Service, Root Directory `server`, Build `npm install`, Start `npm start`).
Paste the `wss://...` address into the app's Home screen.
