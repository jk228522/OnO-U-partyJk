// Yo Party relay: matches host <-> guests by a short party code and forwards their messages.
// It never looks inside "data" (sync payloads / clock pings) - it is a dumb pipe.
const http = require('http');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8080;
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const parties = new Map(); // code -> { host, guests: Map(id -> ws), n }

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Yo Party relay OK');
});
const wss = new WebSocketServer({ server, maxPayload: 64 * 1024 });

function send(ws, obj) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
}

function newCode() {
  for (;;) {
    let c = '';
    for (let i = 0; i < 5; i++) c += ALPHABET[Math.floor(Math.random() * ALPHABET.length)];
    if (!parties.has(c)) return c;
  }
}

wss.on('connection', (ws) => {
  ws.isAlive = true;
  ws.role = null;
  ws.code = null;
  ws.id = null;
  ws.on('pong', () => { ws.isAlive = true; });

  ws.on('message', (raw) => {
    let m;
    try { m = JSON.parse(raw.toString()); } catch (e) { return; }

    if (m.t === 'create' && !ws.role) {
      const code = newCode();
      parties.set(code, { host: ws, guests: new Map(), n: 0 });
      ws.role = 'host';
      ws.code = code;
      send(ws, { t: 'created', code });
    } else if (m.t === 'join' && !ws.role) {
      const code = String(m.code || '').toUpperCase().trim();
      const p = parties.get(code);
      if (!p) { send(ws, { t: 'error', reason: 'Party code not found' }); return; }
      const id = 'g' + (++p.n);
      ws.role = 'guest';
      ws.code = code;
      ws.id = id;
      p.guests.set(id, ws);
      send(ws, { t: 'joined', id });
      send(p.host, { t: 'guest_join', id });
    } else if (m.t === 'to' && ws.role === 'host') {
      const p = parties.get(ws.code);
      if (!p) return;
      const out = { t: 'data', data: m.data };
      if (m.to === '*') {
        for (const g of p.guests.values()) send(g, out);
      } else {
        send(p.guests.get(m.to), out);
      }
    } else if (m.t === 'data' && ws.role === 'guest') {
      const p = parties.get(ws.code);
      if (p) send(p.host, { t: 'from', from: ws.id, data: m.data });
    }
  });

  ws.on('close', () => {
    const p = ws.code && parties.get(ws.code);
    if (!p) return;
    if (ws.role === 'host') {
      for (const g of p.guests.values()) {
        send(g, { t: 'host_left' });
        try { g.close(); } catch (e) {}
      }
      parties.delete(ws.code);
    } else if (ws.role === 'guest') {
      p.guests.delete(ws.id);
      send(p.host, { t: 'guest_leave', id: ws.id });
    }
  });
});

// Keep-alive + drop dead sockets (proxies close idle connections).
setInterval(() => {
  wss.clients.forEach((ws) => {
    if (!ws.isAlive) { ws.terminate(); return; }
    ws.isAlive = false;
    try { ws.ping(); } catch (e) {}
  });
}, 25000);

server.listen(PORT, '0.0.0.0', () => console.log('Yo Party relay listening on ' + PORT));
